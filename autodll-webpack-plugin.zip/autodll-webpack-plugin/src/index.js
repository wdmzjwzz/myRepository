module.exports = require('./plugin').default;
